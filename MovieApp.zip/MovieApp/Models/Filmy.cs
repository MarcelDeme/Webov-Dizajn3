﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApp.Models
{
    public class Filmy
    {
        public int Id { get; set; }
        public string Názov { get; set; }
        public string Žáner { get; set; }
        public string Rok { get; set; }
       
    }
}
